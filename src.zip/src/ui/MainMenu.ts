export class MainMenu {
  readonly root: HTMLDivElement;
  readonly continueButton: HTMLButtonElement;

  constructor(
    overlay: HTMLElement,
    callbacks: {
      newGame: () => void;
      continueGame: () => void;
      save: () => void;
      clear: () => void;
    },
  ) {
    this.root = document.createElement("div");
    this.root.className = "menu-panel";
    this.root.innerHTML = `
      <h1>BlockWorld Local</h1>
      <p>Local voxel sandbox engine with chunked terrain, resource-pack textures, weather, saves and first-person building.</p>
      <div class="button-stack"></div>
    `;
    const stack = this.root.querySelector(".button-stack")!;
    const newButton = this.button("New World", callbacks.newGame);
    this.continueButton = this.button("Continue", callbacks.continueGame);
    const saveButton = this.button("Save Current World", callbacks.save, "secondary");
    const clearButton = this.button("Clear Save", callbacks.clear, "secondary");
    stack.append(newButton, this.continueButton, saveButton, clearButton);
    overlay.appendChild(this.root);
  }

  show(): void {
    this.root.classList.remove("hidden");
  }

  hide(): void {
    this.root.classList.add("hidden");
  }

  private button(label: string, onClick: () => void, tone = ""): HTMLButtonElement {
    const button = document.createElement("button");
    button.className = `ui-button ${tone}`;
    button.type = "button";
    button.textContent = label;
    button.addEventListener("click", onClick);
    return button;
  }
}
