export class PauseMenu {
  readonly root: HTMLDivElement;
  private open = false;

  constructor(
    overlay: HTMLElement,
    callbacks: {
      resume: () => void;
      save: () => void;
      mainMenu: () => void;
    },
  ) {
    this.root = document.createElement("div");
    this.root.className = "pause-panel hidden";
    this.root.innerHTML = `
      <h2>Paused</h2>
      <p>World simulation is paused. Save whenever you want; everything stays local.</p>
      <div class="button-stack"></div>
    `;
    const stack = this.root.querySelector(".button-stack")!;
    stack.append(this.button("Resume", callbacks.resume), this.button("Save", callbacks.save, "secondary"), this.button("Main Menu", callbacks.mainMenu, "secondary"));
    overlay.appendChild(this.root);
  }

  isOpen(): boolean {
    return this.open;
  }

  show(): void {
    this.open = true;
    this.root.classList.remove("hidden");
    if (document.pointerLockElement) document.exitPointerLock();
  }

  hide(): void {
    this.open = false;
    this.root.classList.add("hidden");
  }

  private button(label: string, onClick: () => void, tone = ""): HTMLButtonElement {
    const button = document.createElement("button");
    button.className = `ui-button ${tone}`;
    button.type = "button";
    button.textContent = label;
    button.addEventListener("click", onClick);
    return button;
  }
}
