import { CraftingSystem } from "../items/CraftingSystem";
import { SmeltingSystem } from "../items/SmeltingSystem";
import { PlayerInventory } from "../player/PlayerInventory";
import { TextureManager } from "../assets/TextureManager";
import { BlockRegistry } from "../world/BlockRegistry";

export class InventoryUI {
  readonly root: HTMLDivElement;
  private readonly grid: HTMLDivElement;
  private readonly craftList: HTMLDivElement;
  private open = false;

  constructor(
    overlay: HTMLElement,
    private readonly inventory: PlayerInventory,
    private readonly blocks: BlockRegistry,
    private readonly textures: TextureManager,
    private readonly crafting: CraftingSystem,
    private readonly smelting: SmeltingSystem,
    private readonly onChanged: () => void,
  ) {
    this.root = document.createElement("div");
    this.root.className = "inventory-panel hidden";
    this.root.innerHTML = "<h2>Inventory</h2>";
    this.grid = document.createElement("div");
    this.grid.className = "inventory-grid";
    this.craftList = document.createElement("div");
    this.craftList.className = "craft-list";
    this.root.append(this.grid, this.craftList);
    overlay.appendChild(this.root);
    this.render();
  }

  isOpen(): boolean {
    return this.open;
  }

  toggle(): void {
    this.open ? this.close() : this.show();
  }

  show(): void {
    this.open = true;
    this.root.classList.remove("hidden");
    if (document.pointerLockElement) document.exitPointerLock();
    this.render();
  }

  close(): void {
    this.open = false;
    this.root.classList.add("hidden");
  }

  render(): void {
    this.grid.textContent = "";
    for (let i = 0; i < this.inventory.slots.length; i += 1) {
      const slot = this.inventory.slots[i];
      const cell = document.createElement("button");
      cell.className = "inventory-slot";
      cell.type = "button";
      if (slot) {
        const block = this.blocks.get(slot.blockId);
        cell.title = `${block.displayName} x${slot.count}`;
        const swatch = this.createIcon(slot.blockId, block.color);
        const count = document.createElement("span");
        count.className = "slot-count";
        count.textContent = `${slot.count}`;
        cell.append(swatch, count);
      }
      this.grid.appendChild(cell);
    }

    this.craftList.textContent = "";
    for (const recipe of this.crafting.recipes) {
      const button = document.createElement("button");
      button.className = "ui-button secondary";
      button.type = "button";
      button.textContent = recipe.label;
      button.addEventListener("click", () => {
        if (this.crafting.craft(recipe.id, this.inventory)) {
          this.render();
          this.onChanged();
        }
      });
      this.craftList.appendChild(button);
    }

    const smeltButton = document.createElement("button");
    smeltButton.className = "ui-button secondary";
    smeltButton.type = "button";
    smeltButton.textContent = "Smelt first ore with coal";
    smeltButton.addEventListener("click", () => {
      if (this.smelting.smeltFirstAvailable(this.inventory)) {
        this.render();
        this.onChanged();
      }
    });
    this.craftList.appendChild(smeltButton);
  }

  private createIcon(blockId: number, fallbackColor: number): HTMLSpanElement {
    const icon = document.createElement("span");
    icon.className = "slot-texture";
    const atlas = this.textures.atlas;
    if (atlas) {
      const textureName = this.blocks.getIconTextureForBlock(blockId);
      icon.style.backgroundImage = `url("${atlas.getTileDataUrl(textureName)}")`;
    } else {
      icon.style.background = `#${fallbackColor.toString(16).padStart(6, "0")}`;
    }
    return icon;
  }
}
