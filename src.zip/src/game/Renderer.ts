import * as THREE from "three";
import { Settings } from "./Settings";

export interface FrameCompositor {
  renderFrame(renderer: THREE.WebGLRenderer, scene: THREE.Scene, camera: THREE.PerspectiveCamera): void;
}

export class Renderer {
  readonly root: HTMLDivElement;
  readonly renderer: THREE.WebGLRenderer;
  readonly scene = new THREE.Scene();
  readonly camera: THREE.PerspectiveCamera;
  readonly ambientLight = new THREE.AmbientLight(0xffffff, 0.24);
  readonly hemisphereLight = new THREE.HemisphereLight(0xbddcff, 0x31401f, 0.48);
  readonly sunLight = new THREE.DirectionalLight(0xfff4cf, 1.25);
  readonly moonLight = new THREE.DirectionalLight(0x9fb8ff, 0.14);
  private frameCompositor: FrameCompositor | null = null;

  constructor(container: HTMLElement) {
    this.root = document.createElement("div");
    this.root.className = "game-root";
    container.appendChild(this.root);

    this.renderer = new THREE.WebGLRenderer({ antialias: false, powerPreference: "high-performance" });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, Settings.maxPixelRatio));
    this.renderer.setSize(window.innerWidth, window.innerHeight);
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.05;
    this.renderer.shadowMap.enabled = false;
    this.renderer.domElement.className = "game-canvas";
    this.renderer.domElement.tabIndex = 0;
    this.root.appendChild(this.renderer.domElement);

    // Distant weather must remain visible several kilometres before it arrives.
    this.camera = new THREE.PerspectiveCamera(Settings.initialFov, window.innerWidth / window.innerHeight, 0.1, 40000);
    this.scene.add(this.camera);
    this.scene.add(this.ambientLight);
    this.scene.add(this.hemisphereLight);
    this.scene.add(this.sunLight);
    this.scene.add(this.moonLight);
    this.scene.fog = new THREE.Fog(0x9bb7cf, 120, 980);
    this.sunLight.position.set(80, 120, -60);
    this.moonLight.position.set(-80, 80, 60);

    window.addEventListener("resize", this.resize);
  }

  render(): void {
    if (this.frameCompositor) {
      this.frameCompositor.renderFrame(this.renderer, this.scene, this.camera);
    } else {
      this.renderer.render(this.scene, this.camera);
    }
  }

  setFrameCompositor(compositor: FrameCompositor | null): void {
    this.frameCompositor = compositor;
  }

  setPixelRatioLimit(limit: number): void {
    Settings.maxPixelRatio = limit;
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, Settings.maxPixelRatio));
    this.renderer.setSize(window.innerWidth, window.innerHeight);
  }

  dispose(): void {
    window.removeEventListener("resize", this.resize);
    this.renderer.dispose();
    this.root.remove();
  }

  private readonly resize = (): void => {
    this.camera.aspect = window.innerWidth / window.innerHeight;
    this.camera.updateProjectionMatrix();
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, Settings.maxPixelRatio));
    this.renderer.setSize(window.innerWidth, window.innerHeight);
  };
}
