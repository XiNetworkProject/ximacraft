import * as THREE from "three";
import { CELL_SIZE } from "../weather/WeatherTypes";
import { WeatherEngine } from "../weather/WeatherEngine";
import { deriveCloudLayerState } from "../weather/sky/CloudLayerState";
import { CloudMass } from "./CloudMass";
import { ConvectiveCloudSystem } from "./ConvectiveCloudSystem";

const SCAN_RADIUS = 14;
const MAX_REGIONAL_MASSES = 12;
const SCAN_INTERVAL = 3.5;

/** Keeps living cloud masses aligned with regional weather cells. */
export class RegionalCloudController {
  private readonly byCell = new Map<string, CloudMass>();
  private scanTimer = 0;
  private growthPulse = 0;

  constructor(
    private readonly engine: WeatherEngine,
    private readonly clouds: ConvectiveCloudSystem,
  ) {}

  reset(): void {
    this.byCell.clear();
    this.scanTimer = 0;
    this.growthPulse = 0;
  }

  /** Gives nearby living cumuli to a developing storm without recreating them. */
  claimStormSeeds(x: number, z: number, maxDistance: number, maxCount = 3): CloudMass[] {
    const nearby = [...this.byCell.entries()]
      .map(([key, mass]) => ({ key, mass, distance: Math.hypot(mass.position.x - x, mass.position.z - z) }))
      .filter((candidate) => !candidate.mass.dead && candidate.distance <= maxDistance)
      .sort((a, b) => a.distance - b.distance)
      .slice(0, maxCount);
    for (const candidate of nearby) this.byCell.delete(candidate.key);
    return nearby.map((candidate) => candidate.mass);
  }

  update(dt: number, observerX: number, observerZ: number): void {
    this.scanTimer -= dt;
    this.growthPulse += dt;

    for (const [key, mass] of this.byCell) {
      if (mass.dead || !this.clouds.masses.includes(mass)) {
        this.byCell.delete(key);
        continue;
      }
      const sample = this.engine.sampleAt(mass.position.x, mass.position.z);
      const layers = deriveCloudLayerState(sample);
      const distance = Math.hypot(mass.position.x - observerX, mass.position.z - observerZ);
      if (layers.fairCumulusPotential < 0.055 || sample.humidity < 0.22 || distance > CELL_SIZE * 13) {
        if (mass.lifecycle !== "DISSIPATING" && mass.lifecycle !== "DISSIPATED") mass.dissipate();
        continue;
      }

      const response = 1 - Math.exp(-dt * 0.18);
      mass.humidity = THREE.MathUtils.lerp(
        mass.humidity,
        THREE.MathUtils.clamp(sample.humidity + layers.fairCumulusPotential * 0.24, 0.32, 0.94),
        response,
      );
      // Nuage AMBIANT = cumulus/congestus. Les orages (cumulonimbus) viennent
      // des événements météo, pas du peuplement → "un seul gros orage" net,
      // entouré de cumulus, pas plein de CB partout.
      mass.setInstability(THREE.MathUtils.clamp(sample.instability, 0.12, 0.4));
      mass.upperWind.set(sample.windX, 0, sample.windZ);

      if (this.growthPulse >= 4.5 && layers.fairCumulusPotential > 0.46 && mass.puffs.length < mass.puffBudget) mass.grow();
    }

    if (this.growthPulse >= 4.5) this.growthPulse = 0;
    if (this.scanTimer <= 0) {
      this.scanTimer = SCAN_INTERVAL;
      this.scan(observerX, observerZ);
    }
  }

  private scan(observerX: number, observerZ: number): void {
    const centerCellX = Math.floor(observerX / CELL_SIZE);
    const centerCellZ = Math.floor(observerZ / CELL_SIZE);
    const candidates: Array<{ cellX: number; cellZ: number; score: number }> = [];

    for (let dz = -SCAN_RADIUS; dz <= SCAN_RADIUS; dz += 1) {
      for (let dx = -SCAN_RADIUS; dx <= SCAN_RADIUS; dx += 1) {
        const cellX = centerCellX + dx;
        const cellZ = centerCellZ + dz;
        const x = cellX * CELL_SIZE + CELL_SIZE * 0.5;
        const z = cellZ * CELL_SIZE + CELL_SIZE * 0.5;
        const sample = this.engine.sampleAt(x, z);
        const suitability = deriveCloudLayerState(sample).fairCumulusPotential;
        const seededThreshold = this.hash01(cellX, cellZ) * 0.55 + 0.12;
        if (suitability < 0.06 || suitability < seededThreshold) continue;
        const distancePenalty = Math.hypot(dx, dz) * 0.025;
        const persistence = this.byCell.has(`${cellX},${cellZ}`) ? 0.14 : 0;
        candidates.push({ cellX, cellZ, score: suitability - distancePenalty + persistence });
      }
    }

    candidates.sort((a, b) => b.score - a.score);
    const localPotential = deriveCloudLayerState(this.engine.sampleAt(observerX, observerZ)).fairCumulusPotential;
    const desiredCount = Math.round(
      THREE.MathUtils.lerp(0, MAX_REGIONAL_MASSES, THREE.MathUtils.smoothstep(localPotential, 0.06, 0.82)),
    );
    const selected = candidates.slice(0, desiredCount);
    const selectedKeys = new Set(selected.map((candidate) => `${candidate.cellX},${candidate.cellZ}`));
    for (const [key, mass] of this.byCell) {
      if (selectedKeys.has(key)) continue;
      mass.dissipate();
      this.byCell.delete(key);
    }

    for (const candidate of selected) {
      const key = `${candidate.cellX},${candidate.cellZ}`;
      if (this.byCell.has(key)) continue;
      const offsetX = (this.hash01(candidate.cellX + 71, candidate.cellZ - 19) - 0.5) * CELL_SIZE * 0.58;
      const offsetZ = (this.hash01(candidate.cellX - 43, candidate.cellZ + 97) - 0.5) * CELL_SIZE * 0.58;
      const x = candidate.cellX * CELL_SIZE + CELL_SIZE * 0.5 + offsetX;
      const z = candidate.cellZ * CELL_SIZE + CELL_SIZE * 0.5 + offsetZ;
      const sample = this.engine.sampleAt(x, z);
      const sizeSeed = this.hash01(candidate.cellX * 13 + 5, candidate.cellZ * 7 - 3);
      const mass = this.clouds.spawnAt(x, z, {
        humidity: THREE.MathUtils.clamp(sample.humidity + 0.18, 0.42, 0.95),
        instability: THREE.MathUtils.clamp(sample.instability, 0.14, 0.4),
      });
      // Taille VARIÉE : petit cumulus dense par beau temps, plus gros si le ciel
      // est humide/instable. Chaque nuage est différent (graine par cellule).
      const cumulusPotential = deriveCloudLayerState(sample).fairCumulusPotential;
      const sizeBase = 35 + cumulusPotential * 110 + sample.instability * 60;
      mass.puffBudget = Math.round(THREE.MathUtils.clamp(sizeBase * (0.58 + sizeSeed * 0.78), 38, 190));
      mass.upperWind.set(sample.windX, 0, sample.windZ);
      // Pas de grow() instantané : le nuage NAÎT de rien et se développe tout
      // seul (on le voit grossir), au lieu d'apparaître formé d'un coup.
      this.byCell.set(key, mass);
    }
  }

  private hash01(x: number, z: number): number {
    let value = Math.imul(x | 0, 1597334677) ^ Math.imul(z | 0, 3812015801);
    value = Math.imul(value ^ (value >>> 15), 2246822519);
    return ((value ^ (value >>> 13)) >>> 0) / 4294967295;
  }
}
