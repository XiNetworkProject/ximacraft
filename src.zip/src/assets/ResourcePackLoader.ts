import { textureAliases } from "./textureAliases";

export type LoadedTexture = {
  logicalName: string;
  resolvedName: string;
  image: CanvasImageSource;
  fallback: boolean;
};

export type ResourcePackStats = {
  basePath: string | null;
  loadedCount: number;
  missing: string[];
  fallbacks: string[];
};

export type ResourcePackResult = {
  textures: Map<string, LoadedTexture>;
  stats: ResourcePackStats;
};

const BASE_PATHS = [
  "/resourcepacks/lbpr/assets/minecraft/textures/block/",
  "/resourcepacks/lbpr/LBPR Reload! v.6.5 for mc1.21.5/assets/minecraft/textures/block/",
  "/resourcepack/assets/minecraft/textures/block/",
  "/resourcepack/FaithfulPBR_256_1.1p/assets/minecraft/textures/block/",
  "/resourcepack/FaithfulPBR/assets/minecraft/textures/block/",
];

const fallbackColors: Record<string, [number, number, number, number]> = {
  grass_top: [75, 151, 67, 255],
  grass_side: [70, 130, 62, 255],
  dirt: [121, 82, 50, 255],
  water: [45, 92, 190, 150],
  glass: [220, 246, 255, 95],
  leaves: [56, 130, 60, 210],
  stone: [132, 136, 140, 255],
  sand: [215, 202, 140, 255],
  red_sand: [181, 92, 50, 255],
  bedrock: [34, 34, 34, 255],
  glowstone: [248, 206, 95, 255],
  missing: [220, 32, 180, 255],
};

export class ResourcePackLoader {
  private basePath: string | null = null;

  async load(logicalTextureNames: string[]): Promise<ResourcePackResult> {
    this.basePath = await this.detectBasePath();
    const textures = new Map<string, LoadedTexture>();
    const missing: string[] = [];
    const fallbacks: string[] = [];

    for (const logicalName of logicalTextureNames) {
      if (logicalName === "missing") {
        textures.set(logicalName, {
          logicalName,
          resolvedName: "generated_fallback",
          image: this.createFallbackTexture(logicalName),
          fallback: true,
        });
        continue;
      }

      const loaded = this.basePath ? await this.loadFirstAvailable(logicalName, this.basePath) : null;
      if (loaded) {
        textures.set(logicalName, loaded);
        continue;
      }

      missing.push(logicalName);
      fallbacks.push(logicalName);
      textures.set(logicalName, {
        logicalName,
        resolvedName: "generated_fallback",
        image: this.createFallbackTexture(logicalName),
        fallback: true,
      });
    }

    const stats: ResourcePackStats = {
      basePath: this.basePath,
      loadedCount: [...textures.values()].filter((texture) => !texture.fallback).length,
      missing,
      fallbacks,
    };

    console.groupCollapsed("[ResourcePackLoader] BlockWorld Local texture report");
    console.info("Path used:", stats.basePath ?? "none - generated fallbacks");
    console.info("Textures loaded:", stats.loadedCount);
    console.info("Textures missing:", stats.missing);
    console.info("Fallback textures:", stats.fallbacks);
    console.groupEnd();

    return { textures, stats };
  }

  private async detectBasePath(): Promise<string | null> {
    for (const basePath of BASE_PATHS) {
      if (await this.exists(`${basePath}stone.png`)) {
        return basePath;
      }
    }
    console.warn(
      "[ResourcePackLoader] Resource pack not found. The game will continue with generated fallback textures.",
    );
    return null;
  }

  private async loadFirstAvailable(logicalName: string, basePath: string): Promise<LoadedTexture | null> {
    const candidates = textureAliases[logicalName] ?? [logicalName];
    for (const candidate of candidates) {
      if (candidate.endsWith("_n") || candidate.endsWith("_s")) {
        continue;
      }

      const url = `${basePath}${candidate}.png`;
      if (!(await this.exists(url))) {
        continue;
      }

      const image = await this.loadImage(url);
      if (!image) {
        continue;
      }

      return {
        logicalName,
        resolvedName: candidate,
        image,
        fallback: false,
      };
    }

    console.warn(`[ResourcePackLoader] Missing texture "${logicalName}". Tried: ${candidates.join(", ")}`);
    return null;
  }

  private async exists(url: string): Promise<boolean> {
    try {
      const response = await fetch(url, { method: "HEAD", cache: "no-store" });
      return response.ok;
    } catch {
      try {
        const response = await fetch(url, { method: "GET", cache: "no-store" });
        return response.ok;
      } catch {
        return false;
      }
    }
  }

  private loadImage(url: string): Promise<HTMLImageElement | null> {
    return new Promise((resolve) => {
      const image = new Image();
      image.decoding = "async";
      image.onload = () => resolve(image);
      image.onerror = () => resolve(null);
      image.src = url;
    });
  }

  private createFallbackTexture(logicalName: string): HTMLCanvasElement {
    if (logicalName === "grass_top") return this.createGrassTopTexture();
    if (logicalName === "grass_side") return this.createGrassSideTexture();
    if (logicalName === "dirt") return this.createDirtTexture();
    if (logicalName === "water") return this.createWaterTexture();
    if (logicalName === "glass") return this.createGlassTexture();
    if (logicalName === "leaves") return this.createLeavesTexture();

    const [r, g, b, a] = fallbackColors[logicalName] ?? fallbackColors.missing;
    const canvas = document.createElement("canvas");
    canvas.width = 256;
    canvas.height = 256;
    const context = canvas.getContext("2d")!;
    context.imageSmoothingEnabled = false;
    context.fillStyle = `rgba(${r}, ${g}, ${b}, ${a / 255})`;
    context.fillRect(0, 0, canvas.width, canvas.height);

    context.fillStyle = `rgba(${Math.max(r - 32, 0)}, ${Math.max(g - 32, 0)}, ${Math.max(b - 32, 0)}, ${a / 255})`;
    for (let y = 0; y < 16; y += 1) {
      for (let x = 0; x < 16; x += 1) {
        if ((x + y) % 2 === 0) {
          context.fillRect(x * 16, y * 16, 16, 16);
        }
      }
    }

    context.strokeStyle = `rgba(${Math.min(r + 40, 255)}, ${Math.min(g + 40, 255)}, ${Math.min(b + 40, 255)}, ${a / 255})`;
    context.lineWidth = 6;
    context.strokeRect(3, 3, 250, 250);
    return canvas;
  }

  private createGrassTopTexture(): HTMLCanvasElement {
    return this.makeTexture((context, rand) => {
      this.noiseFill(context, rand, [62, 130, 48], [114, 178, 70], 255);
      for (let i = 0; i < 900; i += 1) {
        const x = Math.floor(rand() * 256);
        const y = Math.floor(rand() * 256);
        const length = 2 + Math.floor(rand() * 8);
        const green = 105 + Math.floor(rand() * 90);
        context.strokeStyle = `rgba(${42 + rand() * 40}, ${green}, ${32 + rand() * 36}, ${0.35 + rand() * 0.4})`;
        context.beginPath();
        context.moveTo(x, y);
        context.lineTo(x + (rand() - 0.5) * 5, y - length);
        context.stroke();
      }
      this.pixelSpeckles(context, rand, 1200, [36, 86, 26], [146, 202, 88], 0.32);
    }, "grass_top");
  }

  private createGrassSideTexture(): HTMLCanvasElement {
    return this.makeTexture((context, rand) => {
      this.drawDirtBase(context, rand);
      const topHeight = 54;
      context.fillStyle = "#4f963f";
      context.fillRect(0, 0, 256, topHeight);
      for (let x = 0; x < 256; x += 4) {
        const blade = 24 + Math.floor(rand() * 42);
        const shade = 75 + Math.floor(rand() * 75);
        context.fillStyle = `rgba(${40 + rand() * 45}, ${shade + 55}, ${35 + rand() * 35}, 0.9)`;
        context.fillRect(x, 0, 4, topHeight + blade);
      }
      for (let i = 0; i < 500; i += 1) {
        const x = Math.floor(rand() * 256);
        const y = Math.floor(rand() * 126);
        context.fillStyle = `rgba(45, ${110 + rand() * 70}, 42, ${0.25 + rand() * 0.35})`;
        context.fillRect(x, y, 2 + Math.floor(rand() * 4), 2 + Math.floor(rand() * 8));
      }
    }, "grass_side");
  }

  private createDirtTexture(): HTMLCanvasElement {
    return this.makeTexture((context, rand) => {
      this.drawDirtBase(context, rand);
      this.pixelSpeckles(context, rand, 1600, [72, 45, 28], [152, 104, 62], 0.42);
    }, "dirt");
  }

  private createWaterTexture(): HTMLCanvasElement {
    return this.makeTexture((context, rand) => {
      const gradient = context.createLinearGradient(0, 0, 256, 256);
      gradient.addColorStop(0, "rgba(40, 96, 190, 0.64)");
      gradient.addColorStop(0.5, "rgba(54, 130, 220, 0.58)");
      gradient.addColorStop(1, "rgba(24, 72, 164, 0.68)");
      context.fillStyle = gradient;
      context.fillRect(0, 0, 256, 256);
      for (let i = 0; i < 38; i += 1) {
        const y = rand() * 256;
        context.strokeStyle = `rgba(180, 230, 255, ${0.1 + rand() * 0.18})`;
        context.lineWidth = 1 + rand() * 2;
        context.beginPath();
        for (let x = -20; x < 276; x += 18) {
          const wave = Math.sin(x * 0.04 + i) * (3 + rand() * 2);
          x === -20 ? context.moveTo(x, y + wave) : context.lineTo(x, y + wave);
        }
        context.stroke();
      }
    }, "water");
  }

  private createGlassTexture(): HTMLCanvasElement {
    return this.makeTexture((context) => {
      context.fillStyle = "rgba(218, 246, 255, 0.32)";
      context.fillRect(0, 0, 256, 256);
      context.strokeStyle = "rgba(255,255,255,0.72)";
      context.lineWidth = 8;
      context.strokeRect(4, 4, 248, 248);
      context.strokeStyle = "rgba(156,214,235,0.45)";
      context.lineWidth = 4;
      context.beginPath();
      context.moveTo(36, 220);
      context.lineTo(220, 36);
      context.moveTo(28, 122);
      context.lineTo(122, 28);
      context.stroke();
    }, "glass");
  }

  private createLeavesTexture(): HTMLCanvasElement {
    return this.makeTexture((context, rand) => {
      context.clearRect(0, 0, 256, 256);
      for (let i = 0; i < 2800; i += 1) {
        const x = Math.floor(rand() * 256);
        const y = Math.floor(rand() * 256);
        const size = 2 + Math.floor(rand() * 8);
        const alpha = rand() < 0.12 ? 0 : 0.55 + rand() * 0.4;
        context.fillStyle = `rgba(${35 + rand() * 50}, ${95 + rand() * 95}, ${32 + rand() * 42}, ${alpha})`;
        context.fillRect(x, y, size, size);
      }
      context.fillStyle = "rgba(20, 70, 20, 0.35)";
      for (let i = 0; i < 120; i += 1) {
        context.fillRect(rand() * 256, rand() * 256, 3 + rand() * 12, 1 + rand() * 4);
      }
    }, "leaves");
  }

  private makeTexture(draw: (context: CanvasRenderingContext2D, rand: () => number) => void, seedText: string): HTMLCanvasElement {
    const canvas = document.createElement("canvas");
    canvas.width = 256;
    canvas.height = 256;
    const context = canvas.getContext("2d")!;
    context.imageSmoothingEnabled = false;
    draw(context, this.makeRandom(seedText));
    return canvas;
  }

  private drawDirtBase(context: CanvasRenderingContext2D, rand: () => number): void {
    this.noiseFill(context, rand, [84, 55, 34], [142, 91, 52], 255);
    for (let i = 0; i < 120; i += 1) {
      context.fillStyle = `rgba(${60 + rand() * 44}, ${38 + rand() * 34}, ${24 + rand() * 20}, ${0.22 + rand() * 0.22})`;
      context.fillRect(rand() * 256, rand() * 256, 8 + rand() * 28, 3 + rand() * 14);
    }
  }

  private noiseFill(
    context: CanvasRenderingContext2D,
    rand: () => number,
    low: [number, number, number],
    high: [number, number, number],
    alpha: number,
  ): void {
    for (let y = 0; y < 256; y += 4) {
      for (let x = 0; x < 256; x += 4) {
        const t = rand();
        const r = Math.floor(low[0] + (high[0] - low[0]) * t);
        const g = Math.floor(low[1] + (high[1] - low[1]) * t);
        const b = Math.floor(low[2] + (high[2] - low[2]) * t);
        context.fillStyle = `rgba(${r}, ${g}, ${b}, ${alpha / 255})`;
        context.fillRect(x, y, 4, 4);
      }
    }
  }

  private pixelSpeckles(
    context: CanvasRenderingContext2D,
    rand: () => number,
    count: number,
    low: [number, number, number],
    high: [number, number, number],
    alpha: number,
  ): void {
    for (let i = 0; i < count; i += 1) {
      const t = rand();
      context.fillStyle = `rgba(${Math.floor(low[0] + (high[0] - low[0]) * t)}, ${Math.floor(
        low[1] + (high[1] - low[1]) * t,
      )}, ${Math.floor(low[2] + (high[2] - low[2]) * t)}, ${alpha})`;
      context.fillRect(rand() * 256, rand() * 256, 1 + rand() * 5, 1 + rand() * 5);
    }
  }

  private makeRandom(seedText: string): () => number {
    let seed = 2166136261;
    for (let i = 0; i < seedText.length; i += 1) {
      seed ^= seedText.charCodeAt(i);
      seed = Math.imul(seed, 16777619);
    }
    return () => {
      seed += 0x6d2b79f5;
      let t = seed;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
}
