import { ColdFrontEvent } from "./events/ColdFrontEvent";
import { WarmFrontEvent } from "./events/WarmFrontEvent";
import { WeatherEngine } from "./WeatherEngine";
import { CELL_SIZE } from "./WeatherTypes";

export type WeatherRegime =
  | "CLEAR"
  | "MOISTURE_RETURN"
  | "WARM_FRONT"
  | "STRATIFORM_RAIN"
  | "CONVECTIVE_OUTBREAK"
  | "COLD_FRONT"
  | "WINTER_STORM"
  | "CLEARING";

/** Creates coherent regional sequences instead of rolling unrelated weather. */
export class WeatherDirector {
  regime: WeatherRegime = "CLEAR";
  private regimeTimer = 8;
  private gridTimer = 0;
  private flowX = 0;
  private flowZ = 1;

  constructor(private readonly engine: WeatherEngine) {}

  debugState(): {
    regime: WeatherRegime;
    secondsUntilTransition: number;
    activeEvents: number;
    flowX: number;
    flowZ: number;
  } {
    return {
      regime: this.regime,
      secondsUntilTransition: Math.max(0, this.regimeTimer),
      activeEvents: this.engine.activeEventCount,
      flowX: this.flowX,
      flowZ: this.flowZ,
    };
  }

  reset(): void {
    this.regime = "CLEAR";
    this.regimeTimer = 8;
    this.gridTimer = 0;
    this.chooseFlow();
  }

  /** Holds a deterministic cinematic regime without spawning random events. */
  hold(regime: WeatherRegime, durationSeconds = 900): void {
    this.regime = regime;
    this.regimeTimer = Math.max(1, durationSeconds);
    this.gridTimer = 0;
  }

  update(dt: number): void {
    this.regimeTimer -= dt;
    this.gridTimer -= dt;
    if (this.gridTimer <= 0) {
      this.gridTimer = 12;
      this.ensureRegionalCells();
    }
    if (this.regimeTimer > 0 || this.engine.activeEventCount >= 6) return;
    this.advanceRegime();
  }

  private advanceRegime(): void {
    const observer = this.engine.getObserver();
    const upwind = this.pointUpwind(6200);
    const upstream = this.engine.sampleAt(upwind.x, upwind.z);

    switch (this.regime) {
      case "CLEAR": {
        const roll = Math.random();
        if (upstream.temperature <= 2 && roll < 0.24) {
          this.regime = "WINTER_STORM";
          this.regimeTimer = this.duration(260, 420);
          this.spawnWinterStorm();
        } else if (upstream.temperature > 7 && roll < 0.22 + upstream.instability * 0.34) {
          // Une cellule isolée peut naître au milieu d'un ciel autrement clair.
          this.regime = "CONVECTIVE_OUTBREAK";
          this.regimeTimer = this.duration(180, 300);
          this.spawnConvection(upstream.instability, true);
        } else if (roll < 0.72) {
          this.regime = "MOISTURE_RETURN";
          this.regimeTimer = this.duration(90, 170);
          this.spawnMoisture(observer.x, observer.z);
        } else {
          this.regime = "WARM_FRONT";
          this.regimeTimer = this.duration(190, 320);
          this.spawnWarmFront();
        }
        break;
      }
      case "MOISTURE_RETURN": {
        const roll = Math.random();
        if (upstream.temperature <= 3) {
          this.regime = "WINTER_STORM";
          this.regimeTimer = this.duration(280, 430);
          this.spawnWinterStorm();
        } else if (roll < 0.24) {
          this.regime = "CLEARING";
          this.regimeTimer = this.duration(90, 170);
          this.spawnClearing();
        } else if (roll < 0.55) {
          this.regime = "STRATIFORM_RAIN";
          this.regimeTimer = this.duration(180, 330);
          this.spawnRainBand();
        } else if (roll < 0.82) {
          this.regime = "WARM_FRONT";
          this.regimeTimer = this.duration(180, 300);
          this.spawnWarmFront();
        } else {
          this.regime = "CONVECTIVE_OUTBREAK";
          this.regimeTimer = this.duration(170, 280);
          this.spawnConvection(upstream.instability);
        }
        break;
      }
      case "WARM_FRONT": {
        const roll = Math.random();
        if (upstream.temperature > 8 && upstream.instability > 0.2 && roll < 0.4) {
          this.regime = "CONVECTIVE_OUTBREAK";
          this.regimeTimer = this.duration(170, 280);
          this.spawnConvection(upstream.instability);
        } else if (roll < 0.67) {
          this.regime = "STRATIFORM_RAIN";
          this.regimeTimer = this.duration(160, 290);
          this.spawnRainBand();
        } else if (roll < 0.84) {
          this.regime = "COLD_FRONT";
          this.regimeTimer = this.duration(160, 250);
          this.spawnColdFront(upstream.instability);
        } else {
          this.regime = "CLEARING";
          this.regimeTimer = this.duration(110, 190);
          this.spawnClearing();
        }
        break;
      }
      case "STRATIFORM_RAIN":
        this.regime = upstream.instability > 0.5 && Math.random() < 0.3 ? "CONVECTIVE_OUTBREAK" : "CLEARING";
        this.regimeTimer = this.regime === "CONVECTIVE_OUTBREAK" ? this.duration(160, 260) : this.duration(100, 190);
        if (this.regime === "CONVECTIVE_OUTBREAK") this.spawnConvection(upstream.instability);
        else this.spawnClearing();
        break;
      case "CONVECTIVE_OUTBREAK":
        this.regime = Math.random() < 0.68 ? "CLEARING" : "COLD_FRONT";
        this.regimeTimer = this.regime === "CLEARING" ? this.duration(110, 210) : this.duration(150, 240);
        if (this.regime === "CLEARING") this.spawnClearing();
        else this.spawnColdFront(Math.max(0.55, upstream.instability));
        break;
      case "COLD_FRONT":
      case "WINTER_STORM":
        this.regime = "CLEARING";
        this.regimeTimer = this.duration(100, 180);
        this.spawnClearing();
        break;
      case "CLEARING":
        this.regime = "CLEAR";
        this.regimeTimer = this.duration(80, 170);
        this.chooseFlow();
        break;
    }
  }

  private spawnMoisture(x: number, z: number): void {
    const area = this.engine.spawnCloudyArea(3000, x - this.flowX * 2200, z - this.flowZ * 2200);
    area.intensity = 0.58;
    area.maxAge = 320;
    area.speed = 5;
    area.setDirection({ x: this.flowX, z: this.flowZ });
    this.engine.setWind(this.flowX * 7, this.flowZ * 7);
  }

  private spawnWarmFront(): void {
    const p = this.pointUpwind(7200);
    const event = new WarmFrontEvent({
      x: p.x,
      z: p.z,
      radius: 3800,
      intensity: 0.68,
      maxAge: 760,
      speed: 9,
      direction: { x: this.flowX, z: this.flowZ },
    });
    this.engine.spawnWarmFront(event);
    this.engine.setWind(this.flowX * 10, this.flowZ * 10);
  }

  private spawnConvection(instability: number, isolated = false): void {
    const p = this.pointUpwind(isolated ? 5200 : 6800);
    const crossX = -this.flowZ;
    const crossZ = this.flowX;
    const count = isolated ? 1 : 1 + Math.floor(Math.random() * 3);
    for (let index = 0; index < count; index += 1) {
      const offset = (index - (count - 1) * 0.5) * (1300 + Math.random() * 650);
      const event = this.engine.spawnStormCell(
        (isolated ? 1800 : 1200) + Math.random() * (isolated ? 900 : 850),
        p.x + crossX * offset,
        p.z + crossZ * offset,
      );
      event.intensity = Math.min(1, 0.72 + instability * 0.25 + Math.random() * 0.12);
      event.maxAge = 520 + Math.random() * 220;
      event.speed = 11 + Math.random() * 5;
      event.setDirection({ x: this.flowX, z: this.flowZ });
    }
    this.engine.setWind(this.flowX * 17 + crossX * 3, this.flowZ * 17 + crossZ * 3);
  }

  private spawnRainBand(): void {
    const p = this.pointUpwind(5600);
    const rain = this.engine.spawnRainBand(2600 + Math.random() * 1800, p.x, p.z);
    rain.intensity = 0.46 + Math.random() * 0.28;
    rain.maxAge = 460 + Math.random() * 260;
    rain.speed = 7 + Math.random() * 5;
    rain.setDirection({ x: this.flowX, z: this.flowZ });
    this.engine.setWind(this.flowX * 9, this.flowZ * 9);
  }

  private spawnColdFront(instability: number): void {
    const p = this.pointUpwind(7600);
    const event = new ColdFrontEvent({
      x: p.x,
      z: p.z,
      radius: 3900,
      intensity: Math.min(1, 0.76 + instability * 0.2),
      maxAge: 700,
      speed: 15,
      direction: { x: this.flowX, z: this.flowZ },
    });
    this.engine.spawnColdFront(event);
    this.engine.setWind(this.flowX * 19, this.flowZ * 19);
  }

  private spawnWinterStorm(): void {
    const p = this.pointUpwind(6500);
    const event = this.engine.spawnStormCell(2600, p.x, p.z, "snow");
    event.intensity = 0.82 + Math.random() * 0.16;
    event.maxAge = 760;
    event.speed = 8;
    event.setDirection({ x: this.flowX, z: this.flowZ });
    this.engine.setWind(this.flowX * 16, this.flowZ * 16);
  }

  private spawnClearing(): void {
    const p = this.pointUpwind(2600);
    const clearing = this.engine.spawnClearing(4200, p.x, p.z);
    clearing.intensity = 0.85;
    clearing.maxAge = 360;
    clearing.speed = 10;
    clearing.setDirection({ x: this.flowX, z: this.flowZ });
    this.engine.setWind(this.flowX * 8, this.flowZ * 8);
  }

  private ensureRegionalCells(): void {
    const observer = this.engine.getObserver();
    for (let dz = -5; dz <= 5; dz += 1) {
      for (let dx = -5; dx <= 5; dx += 1) {
        this.engine.getCellAt(observer.x + dx * CELL_SIZE, observer.z + dz * CELL_SIZE);
      }
    }
  }

  private pointUpwind(distance: number): { x: number; z: number } {
    const observer = this.engine.getObserver();
    return { x: observer.x - this.flowX * distance, z: observer.z - this.flowZ * distance };
  }

  private chooseFlow(): void {
    const angle = Math.random() * Math.PI * 2;
    this.flowX = Math.cos(angle);
    this.flowZ = Math.sin(angle);
    const speed = 5 + Math.random() * 5;
    this.engine.setWind(this.flowX * speed, this.flowZ * speed);
  }

  private duration(min: number, max: number): number {
    return min + Math.random() * (max - min);
  }
}
