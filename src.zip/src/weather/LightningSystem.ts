/**
 * Logique des éclairs (sans rendu).
 *
 * Pour chaque événement orageux (producesLightning), décide quand un éclair se
 * produit, son type, sa position et s'il est partiellement masqué par le rideau
 * de pluie. Déclenche le tonnerre avec un délai/volume fonction de la distance.
 *
 * Types (cf. cahier des charges) :
 *  - INTRA_CLOUD     : flash dans le nuage (le plus fréquent, visible de loin) ;
 *  - CLOUD_TO_CLOUD  : éclair entre zones nuageuses ;
 *  - CLOUD_TO_GROUND : trait jusqu'au sol, flash global plus fort ;
 *  - EMBEDDED_IN_RAIN: lueur diffuse noyée dans le rideau de pluie ;
 *  - DISTANT         : flash à l'horizon, tonnerre faible/très retardé ou absent.
 */

import * as THREE from "three";
import { WeatherEvent } from "./events/WeatherEvent";

export enum LightningType {
  INTRA_CLOUD = "INTRA_CLOUD",
  CLOUD_TO_CLOUD = "CLOUD_TO_CLOUD",
  CLOUD_TO_GROUND = "CLOUD_TO_GROUND",
  EMBEDDED_IN_RAIN = "EMBEDDED_IN_RAIN",
  DISTANT = "DISTANT",
}

export interface LightningStrike {
  eventId: number;
  type: LightningType;
  x: number;
  z: number;
  cloudBaseY: number;
  cloudTopY: number;
  cloudRadius: number;
  /** Force du flash 0..1. */
  intensity: number;
  /** Distance à l'observateur (blocs). */
  distance: number;
  /** Masquage par la pluie 0..1 (1 = très diffus). */
  embedded: number;
  seed: number;
  /** Position de la décharge relativement au centre de l'événement. */
  localOffset: THREE.Vector3;
  flashRadius: number;
  startTime: number;
  duration: number;
  branchCount: number;
}

/** Vitesse du son en blocs/seconde (réglée pour le ressenti de jeu). */
const SOUND_SPEED = 180;
const MAX_AUDIBLE = 5000;

export class LightningSystem {
  private time = 0;
  /** Tonnerre : (delaiSecondes, puissance0..1). Branché sur le SoundManager. */
  onThunder: ((delaySeconds: number, power: number) => void) | null = null;

  /**
   * Avance la simulation et renvoie les éclairs déclenchés pendant ce pas.
   * @param events événements actifs
   * @param ox/oz position de l'observateur
   * @param nightFactor 0 (jour) .. 1 (nuit) — modulera le rendu (pas la logique)
   */
  update(dt: number, events: readonly WeatherEvent[], ox: number, oz: number): LightningStrike[] {
    this.time += dt;
    const strikes: LightningStrike[] = [];

    for (const event of events) {
      if (!event.producesLightning) continue;
      // Fréquence ∝ intensité (proxy de thunderRisk). ~0..0.7 éclair/s.
      const rate = event.intensity * (event.precip === "snow" ? 0.72 : 1.05);
      if (Math.random() > rate * dt) continue;

      const strike = this.makeStrike(event, ox, oz);
      strikes.push(strike);
      this.scheduleThunder(strike);
    }

    return strikes;
  }

  private makeStrike(event: WeatherEvent, ox: number, oz: number): LightningStrike {
    // Position : dans le nuage, dispersée sur le rayon de l'orage.
    const angle = Math.random() * Math.PI * 2;
    const cloudRadius = Math.max(3000, Math.min(10000, event.radius * 4.2));
    const spread = cloudRadius * 0.4 * Math.sqrt(Math.random());
    const offsetX = Math.cos(angle) * spread;
    const offsetZ = Math.sin(angle) * spread;
    const x = event.x + offsetX;
    const z = event.z + offsetZ;
    const distance = Math.hypot(x - ox, z - oz);

    let type: LightningType;
    let embedded = 0;
    const roll = Math.random();

    if (roll < 0.68) {
      type = LightningType.INTRA_CLOUD;
    } else if (event.precip !== "none" && roll < 0.82) {
      type = LightningType.EMBEDDED_IN_RAIN;
      embedded = 0.5 + Math.random() * 0.4; // noyé dans le rideau
    } else if (roll < 0.92) {
      type = LightningType.CLOUD_TO_CLOUD;
    } else {
      type = distance < 1800 && roll < 0.98
        ? LightningType.CLOUD_TO_GROUND
        : distance > 9000
          ? LightningType.DISTANT
          : LightningType.INTRA_CLOUD;
    }

    const intensity = (type === LightningType.CLOUD_TO_GROUND ? 1 : 0.6 + Math.random() * 0.3) * event.intensity;
    const cloudTopY = event.cloudBaseY + Math.max(4500, Math.min(12000, event.radius * 5));
    const localY = type === LightningType.CLOUD_TO_GROUND
      ? event.cloudBaseY + 80
      : THREE.MathUtils.lerp(event.cloudBaseY, cloudTopY, 0.24 + Math.random() * 0.58);
    const flashRadius = THREE.MathUtils.clamp(
      cloudRadius * (type === LightningType.INTRA_CLOUD ? 0.2 : type === LightningType.EMBEDDED_IN_RAIN ? 0.28 : 0.15),
      480,
      2600,
    );
    const duration = type === LightningType.EMBEDDED_IN_RAIN
      ? 0.32 + Math.random() * 0.24
      : 0.12 + Math.random() * 0.2;
    const branchCount = type === LightningType.CLOUD_TO_GROUND
      ? 4 + Math.floor(Math.random() * 4)
      : type === LightningType.CLOUD_TO_CLOUD
        ? 2 + Math.floor(Math.random() * 4)
        : 0;
    return {
      eventId: event.id,
      type,
      x,
      z,
      cloudBaseY: event.cloudBaseY,
      cloudTopY,
      cloudRadius,
      intensity,
      distance,
      embedded,
      seed: Math.floor(Math.random() * 0x7fffffff),
      localOffset: new THREE.Vector3(offsetX, localY - event.cloudBaseY, offsetZ),
      flashRadius,
      startTime: this.time,
      duration,
      branchCount,
    };
  }

  private scheduleThunder(strike: LightningStrike): void {
    if (!this.onThunder || strike.distance > MAX_AUDIBLE) return;
    // Très loin : flash souvent silencieux.
    if (strike.type === LightningType.DISTANT && Math.random() < 0.5) return;
    const delay = strike.distance / SOUND_SPEED;
    const power = Math.max(0, strike.intensity * (1 - strike.distance / MAX_AUDIBLE));
    this.onThunder(delay, power);
  }
}
