import * as THREE from "three";

export type PrecipitationVisualKind = "rain" | "snow" | "hail";

export interface PrecipitationLighting {
  dayFactor: number;
  lightning: number;
}

const NIGHT_COLORS: Record<PrecipitationVisualKind, THREE.Color> = {
  rain: new THREE.Color(0x283746),
  snow: new THREE.Color(0x687581),
  hail: new THREE.Color(0x71808d),
};

const DAY_COLORS: Record<PrecipitationVisualKind, THREE.Color> = {
  rain: new THREE.Color(0x8298a6),
  snow: new THREE.Color(0xc2ccd3),
  hail: new THREE.Color(0xb6c2cb),
};

const FLASH_COLOR = new THREE.Color(0xdce9f7);

export function precipitationColor(
  kind: PrecipitationVisualKind,
  lighting: PrecipitationLighting,
  target: THREE.Color,
): THREE.Color {
  const day = THREE.MathUtils.clamp(lighting.dayFactor, 0, 1);
  const flash = THREE.MathUtils.clamp(lighting.lightning, 0, 1);
  target.lerpColors(NIGHT_COLORS[kind], DAY_COLORS[kind], 0.16 + day * 0.84);
  return target.lerp(FLASH_COLOR, flash * 0.72);
}

export function precipitationOpacity(
  kind: PrecipitationVisualKind,
  intensity: number,
  lighting: PrecipitationLighting,
): number {
  const base = kind === "rain"
    ? 0.055 + intensity * 0.23
    : kind === "snow"
      ? 0.11 + intensity * 0.22
      : 0.16 + intensity * 0.28;
  const nightAttenuation = THREE.MathUtils.lerp(0.62, 1, THREE.MathUtils.clamp(lighting.dayFactor, 0, 1));
  return base * nightAttenuation + THREE.MathUtils.clamp(lighting.lightning, 0, 1) * 0.16;
}
