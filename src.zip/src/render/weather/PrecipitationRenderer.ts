import * as THREE from "three";
import { PrecipKind, WeatherSample } from "../../weather/WeatherTypes";
import {
  PrecipitationLighting,
  precipitationColor,
  precipitationOpacity,
} from "./PrecipitationLightModel";

type PrecipVisualKind = "none" | "rain" | "snow" | "hail";

const RAIN_SEGMENTS = 15000;
const SNOW_POINTS = 12000;
const AREA = 30;
const HEIGHT = 42;

/** Dense, camera-centred precipitation animated entirely on the GPU. */
export class PrecipitationRenderer {
  private readonly rainGeometry = new THREE.BufferGeometry();
  private readonly rainMaterial: THREE.ShaderMaterial;
  private readonly rainLines: THREE.LineSegments;
  private readonly flakeGeometry = new THREE.BufferGeometry();
  private readonly flakeMaterial: THREE.ShaderMaterial;
  private readonly flakes: THREE.Points;
  private readonly flakeTexture = this.createFlakeTexture();
  private time = 0;

  constructor(private readonly scene: THREE.Scene) {
    this.buildRainGeometry();
    this.rainMaterial = new THREE.ShaderMaterial({
      transparent: true,
      depthWrite: false,
      blending: THREE.NormalBlending,
      uniforms: {
        uTime: { value: 0 },
        uWind: { value: new THREE.Vector2() },
        uFall: { value: 70 },
        uLength: { value: 1 },
        uArea: { value: AREA },
        uHeight: { value: HEIGHT },
        uOpacity: { value: 0 },
        uColor: { value: new THREE.Color(0x9fb3c2) },
      },
      vertexShader: `
        attribute float aEnd;
        attribute float aSpeed;
        uniform float uTime;
        uniform vec2 uWind;
        uniform float uFall;
        uniform float uLength;
        uniform float uArea;
        uniform float uHeight;
        void main() {
          float travel = uTime * uFall * aSpeed;
          vec3 p = position;
          p.y = mod(position.y - travel, uHeight);
          p.x = mod(position.x + uTime * uWind.x + uArea, uArea * 2.0) - uArea;
          p.z = mod(position.z + uTime * uWind.y + uArea, uArea * 2.0) - uArea;
          if (aEnd > 0.5) {
            p.x -= uWind.x * uLength * 0.035;
            p.y -= uLength;
            p.z -= uWind.y * uLength * 0.035;
          }
          gl_Position = projectionMatrix * modelViewMatrix * vec4(p, 1.0);
        }
      `,
      fragmentShader: `
        uniform vec3 uColor;
        uniform float uOpacity;
        void main() { gl_FragColor = vec4(uColor, uOpacity); }
      `,
    });
    this.rainLines = new THREE.LineSegments(this.rainGeometry, this.rainMaterial);
    this.rainLines.frustumCulled = false;
    this.rainLines.visible = false;
    this.rainLines.renderOrder = 4;
    scene.add(this.rainLines);

    this.buildFlakeGeometry();
    this.flakeMaterial = new THREE.ShaderMaterial({
      transparent: true,
      depthWrite: false,
      alphaTest: 0.025,
      uniforms: {
        uTime: { value: 0 },
        uWind: { value: new THREE.Vector2() },
        uFall: { value: 6 },
        uArea: { value: AREA },
        uHeight: { value: HEIGHT },
        uSize: { value: 2.2 },
        uSway: { value: 1 },
        uOpacity: { value: 0 },
        uColor: { value: new THREE.Color(0xdce6ed) },
        uMap: { value: this.flakeTexture },
        uHail: { value: 0 },
      },
      vertexShader: `
        attribute float aSpeed;
        attribute float aPhase;
        attribute float aAmp;
        attribute float aSize;
        uniform float uTime;
        uniform vec2 uWind;
        uniform float uFall;
        uniform float uArea;
        uniform float uHeight;
        uniform float uSize;
        uniform float uSway;
        varying float vFade;
        void main() {
          vec3 p = position;
          float t = uTime;
          p.y = mod(position.y - t * uFall * aSpeed, uHeight);
          // Virevoltement : 2 fréquences par flocon → tumbling irrégulier.
          float amp = aAmp * uSway;
          float swayX = sin(t * 1.3 + aPhase) * amp + sin(t * 0.55 + aPhase * 2.3) * amp * 0.5;
          float swayZ = cos(t * 1.05 + aPhase * 1.7) * amp * 0.85 + cos(t * 0.5 + aPhase) * amp * 0.4;
          p.x = mod(position.x + t * uWind.x + swayX + uArea, uArea * 2.0) - uArea;
          p.z = mod(position.z + t * uWind.y + swayZ + uArea, uArea * 2.0) - uArea;
          vec4 mv = modelViewMatrix * vec4(p, 1.0);
          gl_PointSize = clamp(uSize * aSize * 105.0 / max(18.0, -mv.z), 0.65, 4.4);
          // Variation lente d'orientation, sans scintillement blanc lumineux.
          vFade = 0.78 + 0.12 * sin(t * 1.25 + aPhase * 2.0);
          gl_Position = projectionMatrix * mv;
        }
      `,
      fragmentShader: `
        uniform sampler2D uMap;
        uniform vec3 uColor;
        uniform float uOpacity;
        uniform float uHail;
        varying float vFade;
        void main() {
          vec2 centered = gl_PointCoord * 2.0 - 1.0;
          float hailAlpha = 1.0 - smoothstep(0.48, 1.0, length(centered));
          float snowAlpha = texture2D(uMap, gl_PointCoord).a;
          float alpha = mix(snowAlpha, hailAlpha, uHail) * uOpacity * vFade;
          if (alpha < 0.02) discard;
          gl_FragColor = vec4(uColor, alpha);
        }
      `,
    });
    this.flakes = new THREE.Points(this.flakeGeometry, this.flakeMaterial);
    this.flakes.frustumCulled = false;
    this.flakes.visible = false;
    this.flakes.renderOrder = 4;
    scene.add(this.flakes);
  }

  update(
    delta: number,
    sample: WeatherSample,
    cameraPosition: THREE.Vector3,
    enabled = true,
    forced: Readonly<{ kind: PrecipKind; intensity: number }> | null = null,
    lighting: PrecipitationLighting = { dayFactor: 1, lightning: 0 },
  ): void {
    this.time += delta;
    const kind = enabled ? (forced?.kind ?? this.kindFor(sample)) : "none";
    const intensity = THREE.MathUtils.clamp(Math.max(sample.precipitation, forced?.intensity ?? 0), 0, 1);
    this.updateRain(kind, intensity, sample, cameraPosition, lighting);
    this.updateFlakes(kind, intensity, sample, cameraPosition, lighting);
  }

  private updateRain(kind: PrecipVisualKind, intensity: number, sample: WeatherSample, camera: THREE.Vector3, lighting: PrecipitationLighting): void {
    const active = kind === "rain" && intensity > 0.03;
    this.rainLines.visible = active;
    if (!active) return;
    this.rainLines.position.set(camera.x, camera.y - 10, camera.z);
    this.rainGeometry.setDrawRange(0, Math.floor(RAIN_SEGMENTS * (0.22 + intensity * 0.78)) * 2);
    this.rainMaterial.uniforms.uTime.value = this.time;
    this.rainMaterial.uniforms.uWind.value.set(sample.windX * 0.1, sample.windZ * 0.1);
    this.rainMaterial.uniforms.uFall.value = 46 + intensity * 74;
    this.rainMaterial.uniforms.uLength.value = 0.34 + intensity * 1.65;
    this.rainMaterial.uniforms.uOpacity.value = precipitationOpacity("rain", intensity, lighting);
    precipitationColor("rain", lighting, this.rainMaterial.uniforms.uColor.value as THREE.Color);
  }

  private updateFlakes(kind: PrecipVisualKind, intensity: number, sample: WeatherSample, camera: THREE.Vector3, lighting: PrecipitationLighting): void {
    const active = (kind === "snow" || kind === "hail") && intensity > 0.02;
    this.flakes.visible = active;
    if (!active) return;
    const hail = kind === "hail";
    this.flakes.position.set(camera.x, camera.y - 8, camera.z);
    this.flakeGeometry.setDrawRange(0, Math.floor(SNOW_POINTS * (0.24 + intensity * 0.76)));
    this.flakeMaterial.uniforms.uTime.value = this.time;
    this.flakeMaterial.uniforms.uWind.value.set(sample.windX * (hail ? 0.09 : 0.18), sample.windZ * (hail ? 0.09 : 0.18));
    this.flakeMaterial.uniforms.uFall.value = hail ? 28 + intensity * 44 : 3.0 + intensity * 7.5;
    this.flakeMaterial.uniforms.uSize.value = hail ? 1.05 + intensity * 0.55 : 0.82 + intensity * 0.72;
    // Grêle = chute droite (peu de virevoltement) ; neige = forte turbulence.
    this.flakeMaterial.uniforms.uSway.value = hail ? 0.12 : 1.0;
    this.flakeMaterial.uniforms.uHail.value = hail ? 1 : 0;
    this.flakeMaterial.uniforms.uOpacity.value = precipitationOpacity(hail ? "hail" : "snow", intensity, lighting);
    precipitationColor(hail ? "hail" : "snow", lighting, this.flakeMaterial.uniforms.uColor.value as THREE.Color);
  }

  private buildRainGeometry(): void {
    const positions = new Float32Array(RAIN_SEGMENTS * 6);
    const ends = new Float32Array(RAIN_SEGMENTS * 2);
    const speeds = new Float32Array(RAIN_SEGMENTS * 2);
    for (let i = 0; i < RAIN_SEGMENTS; i += 1) {
      const x = (Math.random() - 0.5) * AREA * 2;
      const y = Math.random() * HEIGHT;
      const z = (Math.random() - 0.5) * AREA * 2;
      const speed = 0.72 + Math.random() * 0.38;
      positions.set([x, y, z, x, y, z], i * 6);
      ends[i * 2 + 1] = 1;
      speeds[i * 2] = speeds[i * 2 + 1] = speed;
    }
    this.rainGeometry.setAttribute("position", new THREE.BufferAttribute(positions, 3));
    this.rainGeometry.setAttribute("aEnd", new THREE.BufferAttribute(ends, 1));
    this.rainGeometry.setAttribute("aSpeed", new THREE.BufferAttribute(speeds, 1));
  }

  private buildFlakeGeometry(): void {
    const positions = new Float32Array(SNOW_POINTS * 3);
    const speeds = new Float32Array(SNOW_POINTS);
    const phases = new Float32Array(SNOW_POINTS);
    const amps = new Float32Array(SNOW_POINTS);
    const sizes = new Float32Array(SNOW_POINTS);
    for (let i = 0; i < SNOW_POINTS; i += 1) {
      positions.set([(Math.random() - 0.5) * AREA * 2, Math.random() * HEIGHT, (Math.random() - 0.5) * AREA * 2], i * 3);
      speeds[i] = 0.6 + Math.random() * 0.55;
      phases[i] = Math.random() * Math.PI * 2;
      amps[i] = 0.4 + Math.random() * 1.8; // amplitude de virevoltement variée
      sizes[i] = 0.5 + Math.random() * 1.1; // tailles variées (gros/petits flocons)
    }
    this.flakeGeometry.setAttribute("position", new THREE.BufferAttribute(positions, 3));
    this.flakeGeometry.setAttribute("aSpeed", new THREE.BufferAttribute(speeds, 1));
    this.flakeGeometry.setAttribute("aPhase", new THREE.BufferAttribute(phases, 1));
    this.flakeGeometry.setAttribute("aAmp", new THREE.BufferAttribute(amps, 1));
    this.flakeGeometry.setAttribute("aSize", new THREE.BufferAttribute(sizes, 1));
  }

  private kindFor(sample: WeatherSample): PrecipVisualKind {
    if (sample.precipitation < 0.03) return "none";
    if (sample.temperature <= 1.2) return "snow";
    if (sample.thunderRisk > 0.58 && sample.precipitation > 0.52 && sample.temperature < 18) return "hail";
    return "rain";
  }

  private createFlakeTexture(): THREE.CanvasTexture {
    const canvas = document.createElement("canvas");
    canvas.width = canvas.height = 64;
    const ctx = canvas.getContext("2d")!;
    ctx.translate(32, 32);
    ctx.strokeStyle = "rgba(225,235,242,0.92)";
    ctx.lineWidth = 2.4;
    ctx.lineCap = "round";
    for (let arm = 0; arm < 6; arm += 1) {
      ctx.save();
      ctx.rotate((arm * Math.PI) / 3);
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.lineTo(0, -25);
      ctx.moveTo(0, -13);
      ctx.lineTo(-6, -18);
      ctx.moveTo(0, -13);
      ctx.lineTo(6, -18);
      ctx.moveTo(0, -20);
      ctx.lineTo(-4.5, -23.5);
      ctx.moveTo(0, -20);
      ctx.lineTo(4.5, -23.5);
      ctx.stroke();
      ctx.restore();
    }
    ctx.fillStyle = "rgba(225,235,242,0.9)";
    ctx.beginPath();
    ctx.arc(0, 0, 2.5, 0, Math.PI * 2);
    ctx.fill();
    const texture = new THREE.CanvasTexture(canvas);
    texture.magFilter = THREE.LinearFilter;
    texture.minFilter = THREE.LinearFilter;
    return texture;
  }

  dispose(): void {
    this.scene.remove(this.rainLines, this.flakes);
    this.rainGeometry.dispose();
    this.flakeGeometry.dispose();
    this.rainMaterial.dispose();
    this.flakeMaterial.dispose();
    this.flakeTexture.dispose();
  }
}
