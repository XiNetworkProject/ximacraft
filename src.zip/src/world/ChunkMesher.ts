import * as THREE from "three";
import { TextureAtlas } from "../assets/TextureAtlas";
import { CHUNK_SIZE } from "../utils/Constants";
import { worldToChunk } from "../utils/MathUtils";
import { BlockRegistry } from "./BlockRegistry";
import { BlockFace, BlockId, isSnowLayer, snowLayerLevel } from "./BlockTypes";
import { Chunk } from "./Chunk";
import { World } from "./World";

type FaceBuild = {
  name: BlockFace;
  dir: [number, number, number];
  normal: [number, number, number];
  corners: [number, number, number][];
};

const FACES: FaceBuild[] = [
  { name: "top", dir: [0, 1, 0], normal: [0, 1, 0], corners: [[0, 1, 1], [1, 1, 1], [1, 1, 0], [0, 1, 0]] },
  { name: "bottom", dir: [0, -1, 0], normal: [0, -1, 0], corners: [[0, 0, 0], [1, 0, 0], [1, 0, 1], [0, 0, 1]] },
  { name: "north", dir: [0, 0, -1], normal: [0, 0, -1], corners: [[1, 0, 0], [0, 0, 0], [0, 1, 0], [1, 1, 0]] },
  { name: "south", dir: [0, 0, 1], normal: [0, 0, 1], corners: [[0, 0, 1], [1, 0, 1], [1, 1, 1], [0, 1, 1]] },
  { name: "east", dir: [1, 0, 0], normal: [1, 0, 0], corners: [[1, 0, 1], [1, 0, 0], [1, 1, 0], [1, 1, 1]] },
  { name: "west", dir: [-1, 0, 0], normal: [-1, 0, 0], corners: [[0, 0, 0], [0, 0, 1], [0, 1, 1], [0, 1, 0]] },
];

type MeshBuffers = {
  positions: number[];
  normals: number[];
  uvs: number[];
  colors: number[];
  indices: number[];
};

export type ChunkMeshResult = {
  opaque: THREE.BufferGeometry | null;
  transparent: THREE.BufferGeometry | null;
  water: THREE.BufferGeometry | null;
  triangles: number;
};

export class ChunkMesher {
  constructor(
    private readonly world: World,
    private readonly blockRegistry: BlockRegistry,
    private readonly atlas: TextureAtlas,
  ) {}

  build(chunk: Chunk): ChunkMeshResult {
    const opaque: MeshBuffers = { positions: [], normals: [], uvs: [], colors: [], indices: [] };
    const transparent: MeshBuffers = { positions: [], normals: [], uvs: [], colors: [], indices: [] };
    const water: MeshBuffers = { positions: [], normals: [], uvs: [], colors: [], indices: [] };
    const originX = chunk.cx * CHUNK_SIZE;
    const originZ = chunk.cz * CHUNK_SIZE;

    for (let y = 0; y < 128; y += 1) {
      for (let z = 0; z < CHUNK_SIZE; z += 1) {
        for (let x = 0; x < CHUNK_SIZE; x += 1) {
          const blockId = chunk.getLocal(x, y, z);
          if (blockId === BlockId.AIR) {
            continue;
          }
          const block = this.blockRegistry.get(blockId);
          const target = block.liquid ? water : block.transparent ? transparent : opaque;

          for (const face of FACES) {
            const nx = originX + x + face.dir[0];
            const ny = y + face.dir[1];
            const nz = originZ + z + face.dir[2];
            if (blockId === BlockId.WATER && face.name !== "top" && !this.world.getChunk(worldToChunk(nx), worldToChunk(nz))) {
              continue;
            }
            const neighborId = this.world.getBlock(nx, ny, nz);
            const neighbor = this.blockRegistry.get(neighborId);

            if (!this.shouldRenderFace(blockId, neighborId, face.name, !!(block.transparent || block.liquid), !!(neighbor.transparent || neighbor.liquid))) {
              continue;
            }

            const textureName = this.blockRegistry.getTextureForFace(blockId, face.name);
            this.pushFace(target, originX + x, y, originZ + z, face, textureName, blockId, block.renderHeight ?? 1);
          }
        }
      }
    }

    const opaqueGeometry = this.toGeometry(opaque);
    const transparentGeometry = this.toGeometry(transparent);
    const waterGeometry = this.toGeometry(water);
    return {
      opaque: opaqueGeometry,
      transparent: transparentGeometry,
      water: waterGeometry,
      triangles: opaque.indices.length / 3 + transparent.indices.length / 3 + water.indices.length / 3,
    };
  }

  private shouldRenderFace(
    blockId: BlockId,
    neighborId: BlockId,
    face: BlockFace,
    currentTransparent: boolean,
    neighborTransparent: boolean,
  ): boolean {
    if (isSnowLayer(blockId) && isSnowLayer(neighborId) && face !== "top" && face !== "bottom") {
      return snowLayerLevel(blockId) > snowLayerLevel(neighborId);
    }
    if (neighborId === BlockId.AIR) {
      return true;
    }
    if (blockId === BlockId.WATER && neighborId === BlockId.WATER) {
      return false;
    }
    if (currentTransparent && neighborId === blockId) {
      return false;
    }
    return neighborTransparent || !this.blockRegistry.isOpaque(neighborId);
  }

  private pushFace(
    buffers: MeshBuffers,
    x: number,
    y: number,
    z: number,
    face: FaceBuild,
    textureName: string,
    blockId: BlockId,
    renderHeight: number,
  ): void {
    const baseIndex = buffers.positions.length / 3;
    const uv = this.atlas.getUv(textureName);
    const color = this.faceColor(blockId, face.name, x, y, z);
    const waterLevel = blockId === BlockId.WATER ? 0.88 : renderHeight;

    for (const corner of face.corners) {
      const cy = corner[1] === 1 ? waterLevel : corner[1];
      buffers.positions.push(x + corner[0], y + cy, z + corner[2]);
      buffers.normals.push(face.normal[0], face.normal[1], face.normal[2]);
      buffers.colors.push(color.r, color.g, color.b);
    }

    buffers.uvs.push(uv.u0, uv.v0, uv.u1, uv.v0, uv.u1, uv.v1, uv.u0, uv.v1);
    buffers.indices.push(baseIndex, baseIndex + 1, baseIndex + 2, baseIndex, baseIndex + 2, baseIndex + 3);
  }

  private toGeometry(buffers: MeshBuffers): THREE.BufferGeometry | null {
    if (buffers.positions.length === 0) {
      return null;
    }

    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute("position", new THREE.Float32BufferAttribute(buffers.positions, 3));
    geometry.setAttribute("normal", new THREE.Float32BufferAttribute(buffers.normals, 3));
    geometry.setAttribute("uv", new THREE.Float32BufferAttribute(buffers.uvs, 2));
    geometry.setAttribute("color", new THREE.Float32BufferAttribute(buffers.colors, 3));
    geometry.setIndex(buffers.indices);
    geometry.computeBoundingSphere();
    return geometry;
  }

  private faceColor(blockId: BlockId, face: BlockFace, x: number, y: number, z: number): THREE.Color {
    if (blockId === BlockId.GRASS && face === "top") {
      return this.grassTint(x, z);
    }
    if (blockId === BlockId.GRASS && face !== "bottom") {
      return new THREE.Color(0xcfe6bd);
    }
    if (blockId === BlockId.OAK_LEAVES) {
      const tint = this.foliageTint(x, z, false);
      if (isSnowLayer(this.world.getBlock(x, y + 1, z))) tint.lerp(new THREE.Color(0xb9c3ca), face === "top" ? 0.92 : 0.58);
      return tint;
    }
    if (blockId === BlockId.BIRCH_LEAVES) {
      const tint = this.foliageTint(x, z, true);
      if (isSnowLayer(this.world.getBlock(x, y + 1, z))) tint.lerp(new THREE.Color(0xc0c9cf), face === "top" ? 0.92 : 0.58);
      return tint;
    }
    if (blockId === BlockId.WATER) {
      return new THREE.Color(0x9fdcff);
    }
    if (blockId === BlockId.SNOW_BLOCK || isSnowLayer(blockId)) {
      return new THREE.Color(0xbcc6cc);
    }
    return new THREE.Color(0xffffff);
  }

  private grassTint(x: number, z: number): THREE.Color {
    const biome = this.world.getBiomeAt(x, z);
    switch (biome.id) {
      case "forest":
        return new THREE.Color(0x63b84d);
      case "hills":
        return new THREE.Color(0x78b85a);
      case "mountains":
        return new THREE.Color(0x8cae6b);
      case "snow":
        return new THREE.Color(0xb9cfa6);
      case "desert":
      case "beach":
        return new THREE.Color(0xb9b66b);
      default:
        return new THREE.Color(0x70c850);
    }
  }

  private foliageTint(x: number, z: number, birch: boolean): THREE.Color {
    const biome = this.world.getBiomeAt(x, z);
    if (birch) {
      return new THREE.Color(biome.id === "snow" ? 0xaecb76 : 0x94c95f);
    }
    switch (biome.id) {
      case "forest":
        return new THREE.Color(0x4fa83f);
      case "snow":
        return new THREE.Color(0x789b62);
      case "hills":
      case "mountains":
        return new THREE.Color(0x5f9f48);
      default:
        return new THREE.Color(0x59b143);
    }
  }
}
