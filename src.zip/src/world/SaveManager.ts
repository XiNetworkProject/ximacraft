import { SAVE_SLOT_KEY } from "../utils/Constants";
import { IndexedDbStore } from "../utils/IndexedDbStore";
import { GameMode } from "../player/GameMode";
import { InventorySlot } from "../player/PlayerInventory";
import { WeatherSaveData } from "./WeatherTypes";
import { SurfaceWeatherSaveData } from "../weather/persistence/SurfaceWeatherSaveData";
import { RegionalSnowSaveData } from "../weather/ground/WorldSnowSystem";

export type SaveData = {
  version: 1;
  seed: string;
  player: {
    position: number[];
    velocity: number[];
    gameMode: GameMode;
    creativeFlying: boolean;
    health: number;
    hunger: number;
    inventory: Array<InventorySlot | null>;
    selectedHotbarIndex: number;
  };
  time: {
    ticks: number;
    speed: number;
  };
  weather: WeatherSaveData;
  surfaceWeather?: SurfaceWeatherSaveData;
  regionalSnow?: RegionalSnowSaveData;
  blockChanges: Record<string, number>;
};

export class SaveManager {
  private readonly store = new IndexedDbStore<SaveData>();

  async load(): Promise<SaveData | null> {
    const fromDb = await this.store.get(SAVE_SLOT_KEY);
    if (fromDb) return fromDb;
    const raw = localStorage.getItem(SAVE_SLOT_KEY);
    return raw ? (JSON.parse(raw) as SaveData) : null;
  }

  async save(data: SaveData): Promise<void> {
    const saved = await this.store.set(SAVE_SLOT_KEY, data);
    if (!saved) {
      localStorage.setItem(SAVE_SLOT_KEY, JSON.stringify(data));
    }
  }

  async clear(): Promise<void> {
    await this.store.delete(SAVE_SLOT_KEY);
    localStorage.removeItem(SAVE_SLOT_KEY);
  }
}
