import { CHUNK_SIZE, WORLD_HEIGHT } from "../utils/Constants";
import { Noise } from "../utils/Noise";
import { BlockId } from "./BlockTypes";
import { Chunk } from "./Chunk";
import { BiomeId } from "./BiomeGenerator";

export class StructureGenerator {
  constructor(private readonly noise: Noise) {}

  shouldPlaceTree(x: number, z: number, biome: BiomeId): boolean {
    const chance = biome === "forest" ? 0.085 : biome === "snow" ? 0.028 : biome === "plains" || biome === "hills" ? 0.02 : 0;
    if (chance <= 0) {
      return false;
    }
    return this.noise.random2D(x * 31, z * 31) < chance;
  }

  placeTree(chunk: Chunk, lx: number, baseY: number, lz: number, biome: BiomeId): void {
    const birch = biome === "plains" && this.noise.random3D(chunk.cx * 17 + lx, baseY, chunk.cz * 17 + lz) > 0.55;
    const log = birch ? BlockId.BIRCH_LOG : BlockId.OAK_LOG;
    const leaves = birch ? BlockId.BIRCH_LEAVES : BlockId.OAK_LEAVES;
    this.placeTreeWithBlocks(chunk, lx, baseY, lz, log, leaves);
  }

  placeOakTree(chunk: Chunk, lx: number, baseY: number, lz: number): void {
    this.placeTreeWithBlocks(chunk, lx, baseY, lz, BlockId.OAK_LOG, BlockId.OAK_LEAVES);
  }

  private placeTreeWithBlocks(chunk: Chunk, lx: number, baseY: number, lz: number, log: BlockId, leaves: BlockId): void {
    if (lx < 3 || lx > CHUNK_SIZE - 4 || lz < 3 || lz > CHUNK_SIZE - 4 || baseY + 7 >= WORLD_HEIGHT) {
      return;
    }

    const height = 4 + Math.floor(this.noise.random3D(chunk.cx, baseY, chunk.cz) * 3);
    for (let y = 1; y <= height; y += 1) {
      chunk.setLocal(lx, baseY + y, lz, log);
    }

    const canopyTop = baseY + height + 2;
    for (let y = baseY + height - 1; y <= canopyTop; y += 1) {
      const radius = y === canopyTop ? 1 : 2;
      for (let dz = -radius; dz <= radius; dz += 1) {
        for (let dx = -radius; dx <= radius; dx += 1) {
          const dist = Math.abs(dx) + Math.abs(dz);
          if (dist > radius + 1) {
            continue;
          }
          const tx = lx + dx;
          const tz = lz + dz;
          if (tx < 0 || tx >= CHUNK_SIZE || tz < 0 || tz >= CHUNK_SIZE) {
            continue;
          }
          if (dist === radius + 1 && this.noise.random3D(chunk.cx * 19 + tx, y, chunk.cz * 19 + tz) < 0.45) {
            continue;
          }
          if (chunk.getLocal(tx, y, tz) === BlockId.AIR) {
            chunk.setLocal(tx, y, tz, leaves);
          }
        }
      }
    }

  }
}
