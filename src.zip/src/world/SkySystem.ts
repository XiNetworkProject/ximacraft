import * as THREE from "three";
import { WORLD_DAY_TICKS } from "../utils/Constants";
import { clamp, lerp } from "../utils/MathUtils";
import { Renderer } from "../game/Renderer";
import { Time } from "../game/Time";
import { Player } from "../player/Player";
import { CloudRenderer } from "../render/weather/CloudRenderer";
import { WeatherSystem } from "./WeatherSystem";
import { World } from "./World";
import { WeatherSample } from "../weather/WeatherTypes";
import { deriveCloudLayerState } from "../weather/sky/CloudLayerState";

export class SkySystem {
  readonly clouds: CloudRenderer;
  /** Échantillon du moteur météo régional sous le joueur (injecté par Game). */
  weatherSample: WeatherSample | null = null;
  private readonly skyDome: THREE.Mesh;
  private readonly stars: THREE.Points;
  private readonly sun: THREE.Sprite;
  private readonly moon: THREE.Sprite;

  constructor(private readonly renderer: Renderer) {
    this.skyDome = this.createSkyDome();
    this.stars = this.createStars();
    this.sun = this.createDisc(0xfff2a6, 64);
    this.moon = this.createDisc(0xd9e7ff, 48);
    this.renderer.scene.add(this.skyDome, this.stars, this.sun, this.moon);
    this.clouds = new CloudRenderer(this.renderer.scene);
  }

  updateWithWorld(delta: number, time: Time, weather: WeatherSystem, player: Player, world: World): number {
    const cameraPosition = this.renderer.camera.position;
    const phase = time.ticks / WORLD_DAY_TICKS;
    const angle = phase * Math.PI * 2;
    const sunHeight = Math.sin(angle);
    const dayFactor = clamp(sunHeight * 0.5 + 0.5, 0, 1);
    const dawnFactor = Math.max(0, 1 - Math.abs(sunHeight) * 7) * (phase < 0.5 ? 1 : 0.8);
    const visuals = weather.update(delta, player, world, dayFactor);
    // Couverture combinée : météo legacy OU moteur régional (le plus couvert
    // gagne), pour que `/weather rain` (legacy) et `/weather set cloudy`
    // (moteur) fassent tous deux apparaître les nuages de façon cohérente.
    const sample = this.weatherSample;
    const layers = sample ? deriveCloudLayerState(sample) : null;
    const stratiformCover = layers?.stratiformCover ?? visuals.cloudDensity;
    const totalCover = sample?.cloudCover ?? visuals.cloudDensity;

    this.skyDome.position.copy(cameraPosition);
    this.stars.position.copy(cameraPosition);
    this.rainbowFollow(cameraPosition, weather);

    const nightTop = new THREE.Color(0x061126);
    const dayTop = new THREE.Color(0x4f9de8);
    const nightHorizon = new THREE.Color(0x101b2d);
    const dayHorizon = new THREE.Color(0xb6dcff);
    const top = nightTop.clone().lerp(dayTop, dayFactor);
    const horizon = nightHorizon.clone().lerp(dayHorizon, dayFactor);
    const sunset = new THREE.Color(0xffa35f);
    const violet = new THREE.Color(0x6f7fd8);
    horizon.lerp(sunset, dawnFactor * 0.62);
    top.lerp(violet, dawnFactor * 0.18);
    top.lerp(new THREE.Color(0x171d24), visuals.stormDarkening * 0.76);
    horizon.lerp(new THREE.Color(0x313944), visuals.stormDarkening * 0.64);
    top.lerp(new THREE.Color(0xe6f0ff), visuals.lightningFlash * 0.45);

    const precipitation = sample?.precipitation ?? 0;
    const frozenPrecipitation = sample !== null && sample !== undefined && sample.temperature <= 1.2;
    // Voile de précipitation SOMBRE et dépendant du jour/nuit : un ciel d'orage
    // est gris-bleu foncé (pas blanc) et carrément sombre la nuit → les éclairs
    // ressortent. La neige diffuse un peu plus de lumière le jour.
    const dayHaze = new THREE.Color(frozenPrecipitation ? 0x6f7c88 : 0x52606c);
    const nightHaze = new THREE.Color(frozenPrecipitation ? 0x0b111a : 0x090f16);
    const precipitationHaze = nightHaze.lerp(dayHaze, dayFactor);
    horizon.lerp(precipitationHaze, precipitation * (frozenPrecipitation ? 0.6 : 0.72));
    top.lerp(precipitationHaze, precipitation * (frozenPrecipitation ? 0.4 : 0.55));

    const material = this.skyDome.material as THREE.ShaderMaterial;
    material.uniforms.topColor.value.copy(top);
    material.uniforms.horizonColor.value.copy(horizon);

    const regionalVisibilityLoss = precipitation * (frozenPrecipitation ? 0.9 : 0.72);
    const visibilityLoss = Math.max(Math.pow(1 - visuals.visibility, 1.2), regionalVisibilityLoss);
    const fogNear = lerp(150, 16, visibilityLoss);
    const fogFar = lerp(1120, frozenPrecipitation ? 72 : 145, visibilityLoss);
    this.renderer.scene.fog = new THREE.Fog(horizon, fogNear, fogFar);
    this.renderer.scene.background = top;

    const warmLight = new THREE.Color(0xfff0c2).lerp(new THREE.Color(0xffffff), dayFactor);
    warmLight.lerp(new THREE.Color(0xffb36b), dawnFactor * 0.5);
    this.renderer.sunLight.color.copy(warmLight);
    this.renderer.hemisphereLight.color.copy(top.clone().lerp(new THREE.Color(0xffffff), 0.28));
    this.renderer.hemisphereLight.groundColor.set(dayFactor > 0.25 ? 0x43512d : 0x182033);
    this.renderer.ambientLight.intensity = lerp(0.035, 0.28, dayFactor) * (1 - visuals.stormDarkening * 0.55) + visuals.lightningFlash * 0.34;
    this.renderer.hemisphereLight.intensity = lerp(0.12, 0.64, dayFactor) * (1 - visuals.stormDarkening * 0.62);
    this.renderer.sunLight.intensity = lerp(0.02, 1.55, dayFactor) * (1 - visuals.stormDarkening * 0.78) + visuals.lightningFlash * 0.72;
    this.renderer.moonLight.intensity = lerp(0.24, 0.015, dayFactor) * (1 - totalCover * 0.45);

    const sunDir = new THREE.Vector3(Math.cos(angle) * 280, sunHeight * 280, -120);
    this.renderer.sunLight.position.copy(sunDir);
    this.sun.position.copy(cameraPosition).add(sunDir);
    this.sun.material.opacity = clamp(dayFactor * 1.35 - totalCover * 0.88, 0, 1);
    this.sun.scale.setScalar(34);

    const moonDir = sunDir.clone().multiplyScalar(-1);
    this.renderer.moonLight.position.copy(moonDir);
    this.moon.position.copy(cameraPosition).add(moonDir);
    this.moon.material.opacity = clamp((1 - dayFactor) * 1.12 - totalCover * 0.62, 0, 1);
    this.moon.scale.setScalar(22);

    (this.stars.material as THREE.PointsMaterial).opacity = clamp(Math.pow(1 - dayFactor, 1.35) * (1 - totalCover * 0.88), 0, 1);

    this.clouds.update(delta, {
      cameraPosition,
      sunDirection: sunDir,
      dayFactor,
      dawnFactor,
      stratiformCover,
      windX: sample ? sample.windX : visuals.wind * 4,
      windZ: sample ? sample.windZ : 0,
      darkening: Math.max(visuals.stormDarkening, (sample?.precipitation ?? 0) * 0.5),
    });
    return dayFactor;
  }

  dispose(): void {
    this.skyDome.geometry.dispose();
    (this.skyDome.material as THREE.Material).dispose();
    this.stars.geometry.dispose();
    (this.stars.material as THREE.Material).dispose();
    this.clouds.dispose();
  }

  private rainbowFollow(cameraPosition: THREE.Vector3, weather: WeatherSystem): void {
    weather.rainbowGroup.position.copy(cameraPosition);
  }

  private createSkyDome(): THREE.Mesh {
    const geometry = new THREE.SphereGeometry(1500, 48, 24);
    const material = new THREE.ShaderMaterial({
      side: THREE.BackSide,
      depthWrite: false,
      uniforms: {
        topColor: { value: new THREE.Color(0x3d8edc) },
        horizonColor: { value: new THREE.Color(0xa8d5ff) },
      },
      vertexShader: `
        varying vec3 vSkyDirection;
        void main() {
          vSkyDirection = normalize(position);
          gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }
      `,
      fragmentShader: `
        uniform vec3 topColor;
        uniform vec3 horizonColor;
        varying vec3 vSkyDirection;
        void main() {
          float h = vSkyDirection.y;
          float t = smoothstep(-0.12, 0.86, h);
          vec3 color = mix(horizonColor, topColor, t);
          color += vec3(0.03, 0.045, 0.07) * smoothstep(0.82, 1.0, h);
          gl_FragColor = vec4(color, 1.0);
        }
      `,
    });
    const mesh = new THREE.Mesh(geometry, material);
    mesh.frustumCulled = false;
    return mesh;
  }

  private createStars(): THREE.Points {
    const count = 1600;
    const positions = new Float32Array(count * 3);
    for (let i = 0; i < count; i += 1) {
      const theta = Math.random() * Math.PI * 2;
      const y = Math.random() * 0.86 + 0.12;
      const radius = Math.sqrt(1 - y * y);
      positions[i * 3] = Math.cos(theta) * radius * 430;
      positions[i * 3 + 1] = y * 430;
      positions[i * 3 + 2] = Math.sin(theta) * radius * 430;
    }
    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute("position", new THREE.BufferAttribute(positions, 3));
    const material = new THREE.PointsMaterial({
      color: 0xffffff,
      size: 0.95,
      transparent: true,
      opacity: 0,
      depthWrite: false,
    });
    const points = new THREE.Points(geometry, material);
    points.frustumCulled = false;
    return points;
  }

  private createDisc(color: number, size: number): THREE.Sprite {
    const canvas = document.createElement("canvas");
    canvas.width = size;
    canvas.height = size;
    const context = canvas.getContext("2d")!;
    const gradient = context.createRadialGradient(size / 2, size / 2, 2, size / 2, size / 2, size / 2);
    gradient.addColorStop(0, "#ffffff");
    gradient.addColorStop(0.42, `#${color.toString(16).padStart(6, "0")}`);
    gradient.addColorStop(0.72, `#${color.toString(16).padStart(6, "0")}99`);
    gradient.addColorStop(1, "rgba(255,255,255,0)");
    context.fillStyle = gradient;
    context.fillRect(0, 0, size, size);
    const texture = new THREE.CanvasTexture(canvas);
    const material = new THREE.SpriteMaterial({ map: texture, transparent: true, depthWrite: false });
    const sprite = new THREE.Sprite(material);
    sprite.frustumCulled = false;
    return sprite;
  }
}
