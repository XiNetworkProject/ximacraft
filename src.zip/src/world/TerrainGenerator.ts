import { CHUNK_SIZE, SEA_LEVEL, WORLD_HEIGHT } from "../utils/Constants";
import { clamp, hashString } from "../utils/MathUtils";
import { Noise } from "../utils/Noise";
import { BlockId } from "./BlockTypes";
import { Chunk } from "./Chunk";
import { BiomeGenerator } from "./BiomeGenerator";
import { CaveGenerator } from "./CaveGenerator";
import { OreGenerator } from "./OreGenerator";
import { StructureGenerator } from "./StructureGenerator";

export class TerrainGenerator {
  readonly noise: Noise;
  readonly biomes: BiomeGenerator;
  readonly caves: CaveGenerator;
  readonly ores: OreGenerator;
  readonly structures: StructureGenerator;

  constructor(readonly seed: string) {
    this.noise = new Noise(hashString(seed));
    this.biomes = new BiomeGenerator(this.noise);
    this.caves = new CaveGenerator(this.noise);
    this.ores = new OreGenerator(this.noise);
    this.structures = new StructureGenerator(this.noise);
  }

  getHeight(x: number, z: number): number {
    const continental = this.noise.fbm2D(x * 0.0017, z * 0.0017, 5);
    const erosion = this.noise.fbm2D(x * 0.0048 + 90, z * 0.0048 - 120, 4);
    const hills = this.noise.fbm2D(x * 0.015 + 40, z * 0.015 - 80, 4);
    const detail = this.noise.fbm2D(x * 0.04 - 160, z * 0.04 + 40, 2);
    const ridgeNoise = this.noise.fbm2D(x * 0.0032 - 100, z * 0.0032 + 120, 5);
    const ridges = Math.pow(Math.max(0, 1 - Math.abs(ridgeNoise)), 3);
    const continentLift = continental * 22;
    const erosionCut = Math.max(0, erosion) * 9;
    const mountainLift = ridges * ridges * 54 * clamp((continental + 0.28) / 1.28, 0, 1);
    const rollingLand = hills * 7 + detail * 2.2;
    const rough = SEA_LEVEL + 4 + continentLift + rollingLand + mountainLift - erosionCut;
    return Math.floor(clamp(rough, 18, WORLD_HEIGHT - 14));
  }

  generateChunk(chunk: Chunk): void {
    for (let lz = 0; lz < CHUNK_SIZE; lz += 1) {
      for (let lx = 0; lx < CHUNK_SIZE; lx += 1) {
        const x = chunk.cx * CHUNK_SIZE + lx;
        const z = chunk.cz * CHUNK_SIZE + lz;
        const height = this.getHeight(x, z);
        const biome = this.biomes.sample(x, z, height);

        for (let y = 0; y < WORLD_HEIGHT; y += 1) {
          let block = BlockId.AIR;

          if (y === 0) {
            block = BlockId.BEDROCK;
          } else if (y <= height) {
            if (this.caves.shouldCarve(x, y, z, height)) {
              block = y < SEA_LEVEL - 3 ? BlockId.WATER : BlockId.AIR;
            } else if (y === height) {
              block = this.surfaceBlock(x, z, height, biome.id);
            } else if (y > height - 4) {
              block = this.subsurfaceBlock(height, biome.id);
            } else {
              block = this.ores.oreForStone(x, y, z, biome.id === "mountains" || biome.id === "snow");
            }
          } else if (y <= SEA_LEVEL) {
            block = BlockId.WATER;
          }

          chunk.setLocal(lx, y, lz, block);
        }

        if (
          height > SEA_LEVEL + 2 &&
          (biome.id === "forest" || biome.id === "plains" || biome.id === "hills" || biome.id === "snow") &&
          this.structures.shouldPlaceTree(x, z, biome.id)
        ) {
          this.structures.placeTree(chunk, lx, height, lz, biome.id);
        }
      }
    }

    chunk.generated = true;
    chunk.dirty = true;
  }

  private surfaceBlock(x: number, z: number, height: number, biome: string): BlockId {
    if (height <= SEA_LEVEL - 7) {
      return this.noise.fbm2D(x * 0.09, z * 0.09, 2) > 0.2 ? BlockId.GRAVEL : BlockId.SAND;
    }
    if (height <= SEA_LEVEL + 2 || biome === "beach") {
      return biome === "desert" ? BlockId.RED_SAND : BlockId.SAND;
    }
    if (biome === "desert") {
      return this.noise.fbm2D(x * 0.028 + 20, z * 0.028 - 20, 3) > 0.34 ? BlockId.RED_SAND : BlockId.SAND;
    }
    if (biome === "snow" || height > 92) {
      return BlockId.SNOW_BLOCK;
    }
    if (biome === "mountains" && height > 78) {
      return this.noise.fbm2D(x * 0.06, z * 0.06, 2) > 0.18 ? BlockId.STONE : BlockId.GRASS;
    }
    return BlockId.GRASS;
  }

  private subsurfaceBlock(height: number, biome: string): BlockId {
    if (height <= SEA_LEVEL + 2 || biome === "beach" || biome === "desert") {
      return biome === "desert" ? BlockId.RED_SAND : BlockId.SAND;
    }
    if (biome === "mountains" && height > 82) {
      return BlockId.STONE;
    }
    return BlockId.DIRT;
  }
}
